from .main import app  # para permitir `uvicorn careops:app`
